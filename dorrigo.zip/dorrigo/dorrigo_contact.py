# coding: utf-8

"""
@File     :1.py
@Author    :XieJing
@Date      :2020/10/27
@Copyright :AI
@Desc      :
"""


class dorrigo_contact:

    def __init__(self, fname, lname, pnumber):
        """ construct a new dorrigo_contact
            first name
            last name
            phone number
            Initialise other values to sensible default
        """
        if fname == None or lname == None:
            raise TypeError("A first and last name cannot be set to None")
        else:
            self.fname = fname
            self.lname = lname
            self.pnumber = pnumber
            self.chat_history = []
            self.end = 0
            self.oldest_mes = ""

    def get_first_name(self):
        """ return the first name of the contact """
        return self.fname

    def get_last_name(self):
        """ return the last name of the contact """
        return self.lname

    def get_phone_number(self):
        """ return the phone number of the contact as a string """
        return self.pnumber

    def update_first_name(self, first_name):
        """ if first_name is None the method will do nothing and return.
         The name will only update if the datatype is appropriate
        """
        if first_name is None:
            return
        else:
            if type(first_name) == str:  #判断名字的数据类型
                self.fname = first_name

    def update_last_name(self, last_name):
        """ if last_name is None the method will do nothing and return
         The name will only update if the datatype is appropriate
        """
        if last_name is None:
            return
        else:
            if type(last_name) == str:  #判断名字的数据类型
                self.lname = last_name

    def update_phone_number(self, number):
        """ only allows integer numbers (long type) between 6 and 14 digits
           no spaces allowed, or prefixes of + symbols
           leading 0 digits are allowed
           return True if successfully updated
           if number is None, number is set to an empty string and the method returns False
        """
        if number is None:
            number = ""
            return False
        else:
            # 使用while循环去掉空格和+号
            i = 0
            res = ""
            while i < len(number):
                if number[i] == " " or number[i] == "+":
                    i += 1
                    continue
                res += number[i]
                i += 1
            # 判断是否是纯数字
            num = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
            i = 0
            # 使用while循环来去除数字的字符
            while i < len(res):
                if res[i] in num:
                    i += 1
                    continue
                else:
                    return False
            # 判断号码额长度
            if 6 <= len(res) <= 14:
                self.pnumber = res
                return True
            else:
                return False

    def add_chat_message(self, who_said_it, message):
        """ add a new message to the chat
           The message will take the form
           who_said_it + ": " + message

           if the history is full, the oldest message is replaced
           Hint: keep track of the position of the oldest or newest message!
           always returns True
        """
        # 系统只能由一条消息
        if who_said_it == "Dorrigo":
            return False
        else:
            mes = who_said_it + ": " + str(message)
            # 判断聊天记录储存的数量，如果小于19，则说明还有空间，否则就要覆盖前面的
            if 0 <= self.end < 19:
                if self.end == 1:
                    self.oldest_mes = self.chat_history[0]
                self.chat_history.append(mes)
                self.end += 1
                return True
            else:
                x = 1
                new_chat = []
                # 去除第一条消息，然后在最后一条后面开始加入最新的消息
                while x < 20:
                    new_chat.append(self.chat_history[x])
                    x += 1
                new_chat.append(mes)
                self.chat_history = new_chat
                self.end = 19
                return True

    def clear_chat_history(self):
        """ after this, both last and oldest message should be referring to index 0
           all entries of chat history are set to None
           always returns True
        """
        i = 0
        while i < len(self.chat_history):
            self.chat_history[i] = None  # 让所有消息全部变为None
            i += 1
        self.end = 0
        return True

    def get_last_message(self):
        """ returns the last message
            if no messages, returns None
        """
        if self.chat_history and self.chat_history[-1] is not None:
            return self.chat_history[-1]   #获取最后一条消息
        else:
            return None

    def get_oldest_message(self):
        """ returns the oldest message in the chat history
           depending on if there was ever MAXIMUM_CHAT_HISTORY messages
           1) less than MAXIMUM_CHAT_HISTORY, returns the first message
           2) more than MAXIMUM_CHAT_HISTORY, returns the oldest
           returns None if no messages exist
        """
        if self.chat_history and self.chat_history[0] is not None:
            return self.chat_history[0]  #获取第一条消息
        else:
            return None

    def create_copy(self):
        """ creates a copy of this contact
           returns a new dorrigo_contact object with all data same as the current object
        """
        fname = self.fname
        lname = self.lname
        pnumber = self.pnumber
        chat_history = self.chat_history
        end = self.end
        new_object = dorrigo_contact(fname, lname, pnumber) # 新建一个dorrigo_contact对象
        new_object.chat_history = chat_history
        new_object.end = end
        return new_object

    def print_messages_oldest_to_newest(self):
        """ -- NOT TESTED --
           You can impelement this to help with debugging when failing ed tests
           involving chat history. You can print whatever you like
           Implementers notes: the format is printf("%d %s\n", index, line);
        """
        i = 0
        while i < len(self.chat_history):
            print("%d %s" % (i, self.chat_history[i])) #逐条打印信息
            i += 1