# coding: utf-8

"""
@File     :2.py
@Author    :XieJing
@Date      :2020/10/27
@Copyright :AI
@Desc      :
"""
from dorrigo_contact import dorrigo_contact


class dorrigo_mobile:

    def __init__(self, max_contacts):
        """
        Every phone manufactured has the following attributes

         the phone is off
         the phone has battery life 25
         the phone is not connected
         the phone has signal strength 0
         Each of the contacts stored in the array contacts has a None value

         the owner first name "Dorrigo"
         the owner last name is "Incorporated"
         the owner phone number is "180076237867"
         the owner chat message should have only one message
                 "Thank you for choosing Dorrigo products"
        """
        self.contacts_number = max_contacts
        self.status = "off"
        self.blife = 25
        self.network = "off"
        self.signal = 0
        self.contacts = [None] * self.contacts_number
        self.owner = dorrigo_contact("Dorrigo", "Incorporated", "180076237867")
        self.owner.chat_history = []
        self.owner.chat_history.append("Dorrigo: Thank you for choosing Dorrigo products")

    def get_copy_of_owner_contact(self):
        """  returns a copy of the owner contact details
            return None if the phone is off
        """
        if self.status == "on":
            return self.owner.create_copy() #复制一个owner
        else:
            return None

    def add_contact(self, contact):
        """ only works if phone is on
           will add the contact in the array only if there is space and does not exist
           The method will find an element that is None and set it to be the contact.
           returns True if successful
        """
        if self.status == "on":
            # 先判断是否已经存在contact
            if contact in self.contacts:
                return False
            else:
                c = 0
                while c < len(self.contacts):
                    con = self.contacts[c]
                    # 判断是否还有储存空间
                    if con == None:
                        self.contacts[c] = contact
                        return True
                    else:
                        c += 1
                return False
        else:
            return False

    def remove_contact(self, contact):
        """ only works if phone is on
           find the dorrigo_contact object and set the array element to None
            return True on successful remove
        """
        if self.status == "on":
            return False
            # 寻找该contact，然后变为None
            i = 0
            while i < len(self.contacts):
                if self.contacts[i] == contact:
                    self.contacts[i] = None
                    return True
                i += 1
            return False
        else:
            return False

    def get_number_of_contacts(self):
        """ only works if phone is on
            returns the number of contacts, or -1 if phone is off
        """
        if self.status == "off":
            return -1
        else:
            i = 0
            num = 0 #代表contact的数量
            while i < len(self.contacts):
                if self.contacts[i] is not None:
                    num += 1
                i += 1
            return num

    def search_contact(self, name):
        """ only works if phone is on
           returns a list of all contacts that match first name OR last name
           if phone is off, or no results, None is returned
        """
        if self.status == "off":
            return None
        else:
            if self.contacts is None:
                return False
            else:
                i = 0
                result = []
                while i < len(self.contacts):
                    # 循环遍历所有的联系人
                    if self.contacts[i] is not None:
                        # 匹配fname和lname
                        if self.contacts[i].fname == name or self.contacts[i].lname == name:
                            result.append(self.contacts[i])
                    i += 1
                if result:
                    return result
                else:
                    return None

    def is_phone_on(self):
        """ returns True if phone is on
        """
        if self.status == "on":
            return True
        else:
            return False

    def set_phone_on(self, on):
        """
         set the on status based on the boolean input
         when phone turns on, it costs 5 battery for startup. network is initially disconnected
         when phone turns off it costs 0 battery, network is disconnected
         always return True if turning off
         return False if do not have enough battery level to turn on
         return True otherwise
        """
        if on:
            if self.status == "on":
                return True
            else:
                 # 电量小于5则没法开机
                if self.blife <= 5:
                    return False
                else:
                    self.blife -= 5
                    self.status = "on"
                    self.network = "off"
                    return True
        else:
            if self.status == "on":
                self.status = "off"
                self.network = "off"
            # else:
            #  return False
            return True

    def get_battery_life(self):
        """ Return the battery life level as an integer. if the phone is off, zero is returned.
        """
        if self.status == "off": #如果关机则返回0
            return 0
        else:
            return self.blife

    def change_battery(self, new_battery_level):
        """ Change battery of phone.
           On success. The phone is off and new battery level adjusted and returns True
           If new_battery_level is outside manufacturer specification of [0,100], then
           no changes occur and returns False.
        """
        if type(new_battery_level) != int: # 判断电量是不是数字
            return False
        elif new_battery_level < 0 or new_battery_level > 100: #判断电量的取值范围
            return False
        else:
            self.status = "off"
            self.blife = new_battery_level
            return True

    def is_connected_network(self):
        """ only works if phone is on.
            returns True if the phone is connected to the network
        """
        if self.status == "on":
            if self.network == "on" and self.signal != 0:
                return True
            else:
                return False

    def disconnect_network(self):
        """ only works if phone is on.
            when disconnecting, the signal strength becomes zero
            always returns True
        """
        if self.status == "on":
            self.network = "off"
            self.signal = 0
            return True

    def connect_network(self):
        """ only works if phone is on.
           Connect to network
           if already connected do nothing and return True
           if connecting:
            1) signal strength is set to 1 if it was 0
            2) signal strength will be the previous value if it is not zero
            3) it will cost 2 battery life to do so
           returns the network connected status
        """
        if self.status == "on":
            if self.network == "off":
                # if self.signal == 0:
                #  self.set_signal_strength(1)
                if self.blife > 2:  # 确保电量大于2
                    self.blife -= 2
                    if self.signal == 0: #判断当前的信号强度
                        self.set_signal_strength(1)
                        self.network = "on"
                        return True
                    # if self.signal != 0:
                    #  return True
                    # elif 1 <= self.signal <= 5:
                    #  self.network ="on"
                    #  return True
                    # else:
                    #  return False
                if self.blife == 2: # 如果电量为2，则返回flase
                    self.blife -= 2
                    return False
                if self.blife < 2:
                    self.blife = 0
                    return False
                # self.network = "on"
                # return True
            # if self.network == "on":
            #  return False
        else:
            return False

    def get_signal_strength(self):
        """ only works if phone is on.
           returns a value in range [1,5] if connected to network
           otherwise returns 0
        """
        if self.status == "on":
            if self.network == "on" and 1 <= self.signal <= 5: #确保开机状态和信号强度
                return self.signal
            if self.network == "off":
                return False
            else:
                return 0
        else:
            return 0

    def set_signal_strength(self, new_strength):
        """ only works if phone is on.
           sets the signal strength and may change the network connection status to on or off
           signal of 0 disconnects network
           signal [1,5] can connect to network if not already connected
           if the signal is set outside the range [0,5], nothing will occur and will return False
           returns True on success
        """
        if self.status == "on":
            if new_strength == 0:
                self.signal = new_strength
                self.network = "off"
                return True
            elif new_strength < 0 or new_strength > 5:
                return False
            else:
                if new_strength >= 1 and new_strength <= 5: # 确保信号强度符合取值范围
                    if self.network == "off":
                        self.signal = new_strength
                        self.network = "on"
                    else:
                        self.signal = new_strength
                return True
        return False

    def charge_phone(self):
        """ each charge increases battery level by 10
           the phone has overcharge protection and cannot exceed 100
           returns True if the phone was charged by 10, otherwise False
        """
        if self.blife == 100:
            return False
        elif self.blife + 10 > 100:
            self.blife = 100
            return False
        else:
            self.blife += 10
            return True

    def use_phone(self, k):
        """ Use the phone which costs k units of battery life.
           if the activity exceeds the battery life, the battery automatically
           becomes zero and the phone turns off.
           returns True on successful use (not partial)
        """
        if type(k) == int:
            if k >= self.blife:
                self.blife = 0
                self.set_phone_on(False)  # !!!!!
            else:
                self.blife -= k
            return True