import unittest
from dorrigo_mobile import dorrigo_mobile
from dorrigo_network import dorrigo_network
from dorrigo_contact import dorrigo_contact

class safe_net_tester(unittest.TestCase):
    safe_list = [
        ("Mercury", "safe"),
        ("Venus", "not safe"),
        ("Mars", "cond safe", "1"),
        ("Jupyter", "safe"),
        ("Saturn", "cond safe", "2"),
        ("Uranus", "cond safe", "5"),
        ("Neptune", "cond safe", "2"),
        ("Earth", "cond safe", "0")
    ]

    available_list = [
        ("Mercury", 5, "RSA", "2019-03-10"),
        ("Mercury", 3, "Ceasar", "not certified"),
        ("Mars", 1, "AES", "2019-11-12"),
        ("Mars", 5, "AES", "2019-10-05"),
        ("Saturn", 4, "AES", "2019-06-01"),
        ("Uranus", 1, "AES", "1984-06-24"),
        ("Neptune", 2, "CBC", "2019-10-31"),
        ("Venus", 5, "DES", "not certified"),
        ("Galaxy", 1, "ECB", "2018-04-29")
    ]

    current_date = "2019-11-20"

    # negative case1: the target network is not in the safe_list, return false
    def test1():
        mobile1 = dorrigo_mobile()
        network1_name = "Galaxy"
        network1_signal_strength = 1
        network1_cipher = "ECB"
        network1_date = "2018-04-29"

        target1_test = dorrigo_network(network1_name, network1_signal_strength, network1_cipher, network1_date)
        assert mobile1.is_safe_network(target1_test, available_list, current_date, safe_list) == False

    # negative case2: the target network is not in the available_list, return false
    def test2():
        mobile2 = dorrigo_mobile()
        network2_name = "Earth"
        network2_signal_strength = 1
        network2_cipher = "RSA"
        network2_date = "not certified"

        target2_test = dorrigo_network(network2_name, network2_signal_strength, network2_cipher, network2_date)
        assert mobile2.is_safe_network(target2_test, available_list, current_date, safe_list) == False

    # terget network is safe, return true
    def test3():
        mobile3 = dorrigo_mobile()
        network3_name = "Mercury"
        network3_signal_strength = 5
        network3_cipher = "RSA"
        network3_date = "2019-03-10"

        target3_test = dorrigo_network(network3_name, network3_signal_strength, network3_cipher, network3_date)
        assert mobile3.is_safe_network(target3_test, available_list, current_date, safe_list) == True

    # target network is not safe, return false
    def test4():
        mobile4 = dorrigo_mobile()
        network4_name = "Venus"
        network4_signal_strength = 5
        network4_cipher = "DES"
        network4_date = "not certified"

        target4_test = dorrigo_network(network4_name, network4_signal_strength, network4_cipher, network4_date)
        assert mobile4.is_safe_network(target4_test, available_list, current_date, safe_list) == False

    # test for condition 1
    def test5():
        mobile5 = dorrigo_mobile()
        network5_name = "Mars"
        network5_signal_strength = 1
        network5_cipher = "AES
        network5_date = "2019-11-12"

        target5_test = dorrigo_network(network5_name, network5_signal_strength, network5_cipher, network5_date)
        assert mobile5.is_safe_network(target5_test, available_list, current_date, safe_list) == True





